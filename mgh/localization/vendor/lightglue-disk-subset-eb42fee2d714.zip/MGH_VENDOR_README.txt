DISK/LightGlue inference subset from https://github.com/cvg/LightGlue at eb42fee2d71449efb0aa5c10549752b5d75384d8.
Upstream files and LICENSE are unchanged. __init__.py is a minimal import surface for the included DISK and LightGlue classes; other extractors are not bundled.
Extract into the workspace work/LightGlue directory or add the extracted root to PYTHONPATH. Requires the separately installed PyTorch/Kornia/OpenCV runtime. No upstream benchmark claims are inherited.
